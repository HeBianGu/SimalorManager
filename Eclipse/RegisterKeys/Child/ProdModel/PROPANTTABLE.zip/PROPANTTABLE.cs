﻿#region <版 本 注 释>
/*
 * ========================================================================
 * Copyright(c) 北京奥伯特石油科技有限公司, All Rights Reserved.
 * ========================================================================
 *    
 * 作者：[李海军]   时间：2015/12/1 17:43:33
 * 文件名：WECON
 * 说明：
 * WECON
' O1'  4*  0.0005  'WELL' 'NO' 1* /
--井名 1* 最小产气量  2*  最大水气比  其他参数固定即可 /
/

 * 
 * 修改者：           时间：               
 * 修改说明：
 * ========================================================================
*/
#endregion
using OPT.Product.SimalorManager.Base.AttributeEx;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OPT.Product.SimalorManager.Eclipse.RegisterKeys.Child
{
    [KeyAttribute(EclKeyType = EclKeyType.Include)]
    public class PROPANTTABLE : ItemsKey<PROPANTTABLE.Item>
    {
        public PROPANTTABLE(string _name)
            : base(_name)
        {

        }

        /// <summary> 项实体 </summary>
        public class Item : OPT.Product.SimalorManager.Item
        {
            /// <summary> 压力  </summary>
            public string pressure;

            /// <summary> 支撑剂的渗透率 </summary>
            List<string> nameValues = new List<string>();

            /// <summary> 转换成字符串 </summary>
            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                sb.Append(pressure.ToDD());

                foreach (var v in nameValues)
                {

                    sb.Append(v.ToDD());
                }

                return sb.ToString();
            }

            /// <summary> 解析字符串 </summary>
            public override void Build(List<string> newStr)
            {
                pressure = newStr[0];

                newStr.RemoveAt(0);

                nameValues = newStr;
            }

            /// <summary> 设置支撑剂数量 </summary>
            public void SetCount(int count)
            {
                if (nameValues.Count > count)
                {
                    nameValues.RemoveRange(count, nameValues.Count - count);
                }
                else
                {
                    for (int i = count; i < count - nameValues.Count; i++)
                    {
                        nameValues.Add("0");
                    }
                }
            }

            public string GetValue(int index)
            {
                if (nameValues.Count > index)
                {
                    return nameValues[index];
                }
                else
                {
                    return string.Empty;
                }
            }

            public void SetValue(int index,string v)
            {
                if (nameValues.Count > index)
                {
                    nameValues[index] = v;
                }
            }
        }

    }
}
