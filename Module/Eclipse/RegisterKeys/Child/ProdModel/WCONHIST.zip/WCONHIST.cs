﻿#region <版 本 注 释>
/*
 * ========================================================================
 * Copyright(c) 北京奥伯特石油科技有限公司, All Rights Reserved.
 * ========================================================================
 *    
 * 作者：[李海军]   时间：2015/12/2 14:54:35
 * 文件名：WCONHIST
 * 说明：
WCONHIST
'C1'      'OPEN'      'GRAT'      5.346      7.306  36491.391  2*    112.000  2* /
'C10'      'OPEN'      'GRAT'      4.549     14.091  28848.174  2*     71.600  2* /
'C3'      'OPEN'      'GRAT'      6.670     35.151  46829.810  2*    115.400  2* /
/
 * 
 * 修改者：           时间：               
 * 修改说明：
 * ========================================================================
*/
#endregion
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OPT.Product.SimalorManager.Eclipse.RegisterKeys.Child
{
    /// <summary> 生产井通过WCONPROD关键字定义，设置生产井的目标产量及限制条件，对于含历史数据的，用WCONHIST定义，两个关键字很类似 </summary>
    public class WCONHIST : ItemsKey<WCONHIST.Item>
    {
        public WCONHIST(string _name)
            : base(_name)
        {

        }

        //public WCONHIST(string _name, List<Item> pitems)
        //    : base(_name)
        //{
        //    Items = pitems;
        //}

        ///// <summary> 转换类型 </summary>
        //public WCONPROD ToWCONPROD()
        //{
        //    WCONPROD pWCONPROD = KeyConfigerFactroy.Instance.CreateChildKey<WCONPROD>("WCONPROD");
        //    //foreach (Item item in this.Items)
        //    //{
        //    //    WCONPROD.ItemHY toItem = item.ToProdItem();
        //    //    pWCONPROD.Items.Add(toItem);

        //    //}
        //    return pWCONPROD;
        //}

         /// <summary> 复制一份数据  </summary>
        //public object Clone()
        //{
        //    WCONHIST newWconHist = new WCONHIST("WCONHIST");
        //    //  只复制数据行
        //    newWconHist.Lines = this.Lines;
        //    //  初始化数据集合
        //    newWconHist.CmdGetWellItems();

        //    return newWconHist;
        //}

        /// <summary> 项实体 </summary>
        public class Item : OPT.Product.SimalorManager.Item
        {
            /// <summary> 井名  </summary>
            public string wellName0;
            /// <summary> 开关标志 </summary>
            public string openFlag1;
            /// <summary> 控制模式 </summary>
            public string ctrlModel2;
            /// <summary> 观测日产油量 </summary>
            public string oilPro3;
            /// <summary> 观测日产水量</summary>
            public string waterPro4;
            /// <summary> 观测日产气量 </summary>
            public string gasPro5;
            /// <summary> VFP表号 </summary>
            public string VFP6;
            /// <summary> 人工举升量 </summary>
            public string perCount7;
             /// <summary> 观测THP </summary>
            public string THP8;
            /// <summary> 观测BHP </summary>
            public string BHP9;
            /// <summary> 观测湿气日产量 </summary>
            public string wGasPro10;


           string formatStr = "{0}{1}{2}{3}{4}{5}{6}{7}{8}{9}{10} /";

            /// <summary> 转换成字符串 </summary>
            public override string ToString()
            {
                return string.Format(formatStr, wellName0.ToEclStr(), openFlag1.ToEclStr(), ctrlModel2.ToEclStr(), oilPro3.ToDD(), waterPro4.ToDD(), gasPro5.ToDD(), VFP6.ToDD(), perCount7.ToDD(), THP8.ToDD(), BHP9.ToDD(), wGasPro10.ToDD());
            }

            /// <summary> 解析字符串 </summary>
            public override void Build(List<string> newStr)
            {
                this.ID = Guid.NewGuid().ToString();

                for (int i = 0; i < newStr.Count; i++)
                {
                    switch (i)
                    {
                        case 0:
                            this.wellName0 = newStr[0];
                            break;
                        case 1:
                            this.openFlag1 = newStr[1];
                            break;
                        case 2:
                            this.ctrlModel2 = newStr[2];
                            break;
                        case 3:
                            this.oilPro3 = newStr[3];
                            break;
                        case 4:
                            this.waterPro4 = newStr[4];
                            break;
                        case 5:
                            this.gasPro5 = newStr[5];
                            break;
                        case 6:
                            this.VFP6 = newStr[6];
                            break;
                        case 7:
                            this.perCount7 = newStr[7];
                            break;
                        case 8:
                            this.THP8 = newStr[8];
                            break;
                        case 9:
                            this.BHP9 = newStr[9];
                            break;
                        case 10:
                            this.wGasPro10 = newStr[10];
                            break;
                        default:
                            break;
                    }
                }
            }

            ///// <summary> 转换成预测项 </summary>
            //public WCONPROD.Item ToProdItem()
            //{
            //    WCONPROD.Item toItem = new WCONPROD.Item()
            //    {
            //        jm0 = this.wellName,
            //        kgbz1 = this.openFlag,
            //        kzms2 = this.ctrlModel,
            //        rcyl3 = this.oilPro,
            //        rcsl4 = this.waterPro,
            //        rcql5 = this.gasPro,
            //        liqutPro6 = "1*",
            //        volume7 = "1*",
            //        BHP8 = "1*",   //  产量
            //        THP9 = "1*",
            //        VFP10 = "1*",
            //        scsl11 = "1*",
            //        sqrcl12 = "1*",
            //        zmell13 = "1*",
            //        zqrcl14 = "1*"
            //    };


            //    return toItem;
            //}

        }
    }

}
